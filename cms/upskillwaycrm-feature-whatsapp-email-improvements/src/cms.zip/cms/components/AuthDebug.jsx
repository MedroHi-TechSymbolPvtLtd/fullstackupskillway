import { useState, useEffect } from 'react';
import { Shield, Key, User, AlertCircle, CheckCircle } from 'lucide-react';
import blogService from '../services/blogService.js';

const AuthDebug = () => {
  const [authState, setAuthState] = useState({
    tokens: {},
    user: null,
    isAuthenticated: false,
    lastChecked: null
  });

  const checkAuthState = () => {
    const tokens = {
      access_token: localStorage.getItem('access_token'),
      upskillway_access_token: localStorage.getItem('upskillway_access_token'),
      refresh_token: localStorage.getItem('upskillway_refresh_token'),
      isLoggedIn: localStorage.getItem('isLoggedIn')
    };

    // Also check cookies
    const cookies = document.cookie.split(';').reduce((acc, cookie) => {
      const [key, value] = cookie.trim().split('=');
      if (key && key.includes('upskillway')) {
        acc[key] = value;
      }
      return acc;
    }, {});

    const user = localStorage.getItem('user');
    const parsedUser = user ? JSON.parse(user) : null;

    const isAuthenticated = blogService.isAuthenticated();
    const foundToken = blogService.getAuthToken();

    setAuthState({
      tokens: { ...tokens, ...cookies },
      user: parsedUser,
      isAuthenticated,
      foundToken: foundToken ? `${foundToken.substring(0, 20)}...` : null,
      lastChecked: new Date().toLocaleTimeString()
    });
  };

  useEffect(() => {
    checkAuthState();
    const interval = setInterval(checkAuthState, 5000); // Check every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const testBlogAPI = async () => {
    try {
      console.log('Testing blog API...');
      const response = await blogService.getBlogs({ page: 1, limit: 1 });
      console.log('Blog API test successful:', response);
      alert('Blog API test successful! Check console for details.');
    } catch (error) {
      console.error('Blog API test failed:', error);
      alert(`Blog API test failed: ${error.message}`);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900 flex items-center">
          <Shield className="h-5 w-5 mr-2" />
          Authentication Debug
        </h3>
        <div className="flex items-center space-x-2">
          <button
            onClick={checkAuthState}
            className="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200"
          >
            Refresh
          </button>
          <button
            onClick={testBlogAPI}
            className="px-3 py-1 text-sm bg-green-100 text-green-700 rounded-md hover:bg-green-200"
          >
            Test API
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Authentication Status */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            {authState.isAuthenticated ? (
              <CheckCircle className="h-4 w-4 text-green-500" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-500" />
            )}
            <span className={`text-sm font-medium ${
              authState.isAuthenticated ? 'text-green-700' : 'text-red-700'
            }`}>
              {authState.isAuthenticated ? 'Authenticated' : 'Not Authenticated'}
            </span>
          </div>

          <div className="text-xs text-gray-500 space-y-1">
            <div>Last checked: {authState.lastChecked}</div>
            {authState.foundToken && (
              <div>Active token: {authState.foundToken}</div>
            )}
          </div>
        </div>

        {/* User Info */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">User Info</span>
          </div>
          {authState.user ? (
            <div className="text-xs text-gray-600">
              <div>Email: {authState.user.email}</div>
              {authState.user.role && <div>Role: {authState.user.role}</div>}
            </div>
          ) : (
            <div className="text-xs text-gray-500">No user data</div>
          )}
        </div>
      </div>

      {/* Tokens */}
      <div className="mt-4">
        <div className="flex items-center space-x-2 mb-2">
          <Key className="h-4 w-4 text-gray-400" />
          <span className="text-sm font-medium text-gray-700">Tokens</span>
        </div>
        <div className="grid grid-cols-1 gap-2">
          {Object.entries(authState.tokens).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between text-xs">
              <span className="text-gray-600">{key}:</span>
              <span className={`font-mono ${value ? 'text-green-600' : 'text-red-500'}`}>
                {value ? `${value.substring(0, 20)}...` : 'Not set'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-4 p-3 bg-blue-50 rounded-md">
        <div className="text-sm text-blue-800">
          <strong>Debug Instructions:</strong>
          <ul className="mt-1 list-disc list-inside space-y-1">
            <li>Make sure you're logged in through the login page</li>
            <li>Check that access_token is present in localStorage</li>
            <li>Use "Test API" to verify blog service connectivity</li>
            <li>If authentication fails, try logging out and back in</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AuthDebug;