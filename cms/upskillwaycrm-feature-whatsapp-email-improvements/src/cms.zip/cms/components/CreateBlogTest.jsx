import { useState } from 'react';
import { Plus, CheckCircle, XCircle, Loader } from 'lucide-react';
import blogService from '../services/blogService.js';

const CreateBlogTest = () => {
  const [testResult, setTestResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const testCreateBlog = async () => {
    setLoading(true);
    setTestResult(null);

    try {
      console.log('Testing blog creation...');
      
      const testBlogData = {
        title: "Test Blog Post",
        slug: "test-blog-post-" + Date.now(),
        excerpt: "This is a test blog post created from the CMS",
        content: "This is the full content of the test blog post. It contains some sample text to verify that the blog creation functionality is working correctly.",
        imageUrl: "https://via.placeholder.com/800x400/f97316/ffffff?text=Test+Blog",
        tags: ["test", "cms", "blog"],
        status: "draft"
      };

      console.log('Creating blog with data:', testBlogData);
      
      const response = await blogService.createBlog(testBlogData);
      console.log('Create blog response:', response);

      if (response && response.success) {
        setTestResult({
          success: true,
          message: 'Blog created successfully!',
          data: response.data,
          blogId: response.data?.id
        });
      } else {
        setTestResult({
          success: false,
          message: 'Blog creation failed - no success flag',
          data: response
        });
      }
    } catch (error) {
      console.error('Create blog test error:', error);
      setTestResult({
        success: false,
        message: `Create blog failed: ${error.message}`,
        error: error
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Create Blog Test</h3>
        <button
          onClick={testCreateBlog}
          disabled={loading}
          className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50"
        >
          {loading ? (
            <Loader className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Plus className="h-4 w-4 mr-2" />
          )}
          Test Create Blog
        </button>
      </div>

      {testResult && (
        <div className={`p-4 rounded-lg ${
          testResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-center mb-2">
            {testResult.success ? (
              <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
            ) : (
              <XCircle className="h-5 w-5 text-red-600 mr-2" />
            )}
            <span className={`font-medium ${
              testResult.success ? 'text-green-800' : 'text-red-800'
            }`}>
              {testResult.message}
            </span>
          </div>

          {testResult.success && testResult.data && (
            <div className="text-sm text-green-700 space-y-1">
              <div>Blog ID: {testResult.blogId}</div>
              <div>Title: {testResult.data.title}</div>
              <div>Status: {testResult.data.status}</div>
              <div>Created: {new Date(testResult.data.createdAt).toLocaleString()}</div>
            </div>
          )}

          {!testResult.success && (
            <div className="text-sm text-red-700 mt-2">
              <pre className="whitespace-pre-wrap text-xs">
                {JSON.stringify(testResult.data || testResult.error, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

      <div className="mt-4 text-sm text-gray-600">
        <p>This test creates a sample blog post to verify authentication and API functionality.</p>
        <p className="mt-1">Requires: Valid access token and proper authentication headers.</p>
      </div>
    </div>
  );
};

export default CreateBlogTest;