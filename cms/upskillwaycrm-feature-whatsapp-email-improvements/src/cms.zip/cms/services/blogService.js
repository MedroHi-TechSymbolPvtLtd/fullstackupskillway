// Blog API Service
const API_BASE_URL = 'http://localhost:3000/api/v1';

class BlogService {
  // Verify if user is authenticated
  isAuthenticated() {
    const token = this.getAuthToken();
    return !!token;
  }

  // Get auth token from multiple sources
  getAuthToken() {
    // Try multiple sources for the token
    const sources = [
      () => localStorage.getItem('access_token'), // Direct access_token
      () => localStorage.getItem('upskillway_access_token'), // AuthUtils token
      () => {
        // Try to get from cookies
        const cookies = document.cookie.split(';');
        const tokenCookie = cookies.find(cookie => 
          cookie.trim().startsWith('upskillway_access_token=')
        );
        return tokenCookie ? tokenCookie.split('=')[1] : null;
      }
    ];

    for (const getToken of sources) {
      const token = getToken();
      if (token) {
        console.log('Found auth token from source');
        return token;
      }
    }

    console.warn('No auth token found in any source');
    return null;
  }

  // Get auth headers (optional authentication)
  getAuthHeaders(requireAuth = true) {
    const token = this.getAuthToken();
    
    const headers = {
      'Content-Type': 'application/json'
    };

    if (token) {
      headers.Authorization = `Bearer ${token}`;
      console.log('Using authenticated headers');
    } else if (requireAuth) {
      console.error('No authentication token available');
      throw new Error('Authentication required. Please log in again.');
    } else {
      console.log('Using non-authenticated headers');
    }

    return headers;
  }

  // Get basic headers without authentication
  getBasicHeaders() {
    return {
      'Content-Type': 'application/json'
    };
  }

  // Create a new blog post
  async createBlog(blogData) {
    try {
      console.log('Creating blog with data:', blogData);
      
      const headers = this.getAuthHeaders(true); // Require auth for create
      console.log('Using headers:', { ...headers, Authorization: 'Bearer [HIDDEN]' });
      
      const response = await fetch(`${API_BASE_URL}/blogs`, {
        method: 'POST',
        headers,
        body: JSON.stringify(blogData)
      });

      console.log('Create blog response status:', response.status);
      
      const result = await response.json();
      console.log('Create blog response data:', result);
      
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication failed. Please log in again.');
        }
        throw new Error(result.message || `Failed to create blog (${response.status})`);
      }

      return result;
    } catch (error) {
      console.error('Create blog error:', error);
      
      // If it's a network error, provide a more helpful message
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection and try again.');
      }
      
      throw error;
    }
  }

  // Get all blogs with pagination and filters (no auth required)
  async getBlogs(params = {}) {
    try {
      const queryParams = new URLSearchParams({
        page: params.page || 1,
        limit: params.limit || 10,
        ...(params.status && { status: params.status }),
        ...(params.search && { search: params.search })
      });

      console.log('Fetching blogs with params:', params);
      console.log('Query string:', queryParams.toString());

      // Try with authentication first, fallback to no auth
      let headers;
      try {
        headers = this.getAuthHeaders(false); // Don't require auth
      } catch (error) {
        headers = this.getBasicHeaders();
      }

      const response = await fetch(`${API_BASE_URL}/blogs?${queryParams}`, {
        method: 'GET',
        headers
      });

      console.log('Get blogs response status:', response.status);
      
      const result = await response.json();
      console.log('Get blogs response data:', result);
      
      if (!response.ok) {
        throw new Error(result.message || `Failed to fetch blogs (${response.status})`);
      }

      return result;
    } catch (error) {
      console.error('Get blogs error:', error);
      throw error;
    }
  }

  // Get blog by ID (no auth required)
  async getBlogById(id) {
    try {
      // Try with authentication first, fallback to no auth
      let headers;
      try {
        headers = this.getAuthHeaders(false); // Don't require auth
      } catch (error) {
        headers = this.getBasicHeaders();
      }

      const response = await fetch(`${API_BASE_URL}/blogs/${id}`, {
        method: 'GET',
        headers
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to fetch blog');
      }

      return result;
    } catch (error) {
      console.error('Get blog by ID error:', error);
      throw error;
    }
  }

  // Update blog
  async updateBlog(id, blogData) {
    try {
      const response = await fetch(`${API_BASE_URL}/blogs/${id}`, {
        method: 'PUT',
        headers: this.getAuthHeaders(true), // Require auth for update
        body: JSON.stringify(blogData)
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to update blog');
      }

      return result;
    } catch (error) {
      console.error('Update blog error:', error);
      throw error;
    }
  }

  // Delete blog
  async deleteBlog(id) {
    try {
      const response = await fetch(`${API_BASE_URL}/blogs/${id}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(true) // Require auth for delete
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Failed to delete blog');
      }

      return result;
    } catch (error) {
      console.error('Delete blog error:', error);
      throw error;
    }
  }
}

export default new BlogService();